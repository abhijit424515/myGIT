#include "lib.h"

void A::f(){};
void A::g(){};


