class A {
  public:
	virtual void f();
	virtual void g();
};

