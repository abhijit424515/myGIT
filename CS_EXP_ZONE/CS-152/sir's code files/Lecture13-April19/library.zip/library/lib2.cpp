#include "lib.h"

void A::f(){g();};
void A::g(){};


