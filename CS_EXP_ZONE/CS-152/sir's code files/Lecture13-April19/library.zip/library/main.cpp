#include "lib.h"

int main () {
A a;
	a.f();
	a.g();
}
