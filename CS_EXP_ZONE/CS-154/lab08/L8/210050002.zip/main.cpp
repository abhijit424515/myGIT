#include <iostream>
#include <cmath>
#include <vector>
#include <string>
using namespace std;

int checksimilarity(string n1, string n2);

int main (int argc, char *argv[]) {
  cout<<checksimilarity(argv[1], argv[2])<<endl;
}
